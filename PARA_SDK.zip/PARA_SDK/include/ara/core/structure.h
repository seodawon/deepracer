// ===============================================================================================
// Copyright 2024. PopcornSAR Co.,Ltd. All rights reserved.
//
// This software is copyright protected and proprietary to PopcornSAR Co.,Ltd.
// PopcornSAR Co.,Ltd. grants to you only those rights as set out in the license conditions.
//
// More information is available at https://www.autosar.io
// ===============================================================================================

#ifndef ARA_CORE_INTERNAL_STRUCTURE_H_
#define ARA_CORE_INTERNAL_STRUCTURE_H_

#include "para/serialization/base/structure.h"

#endif  // ARA_CORE_INTERNAL_STRUCTURE_H_
