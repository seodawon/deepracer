// generated from rosidl_generator_c/resource/idl.h.em
// with input from deepracer_interfaces_pkg:msg/InferResultsArray.idl
// generated code does not contain a copyright notice

#ifndef DEEPRACER_INTERFACES_PKG__MSG__INFER_RESULTS_ARRAY_H_
#define DEEPRACER_INTERFACES_PKG__MSG__INFER_RESULTS_ARRAY_H_

#include "deepracer_interfaces_pkg/msg/detail/infer_results_array__struct.h"
#include "deepracer_interfaces_pkg/msg/detail/infer_results_array__functions.h"
#include "deepracer_interfaces_pkg/msg/detail/infer_results_array__type_support.h"

#endif  // DEEPRACER_INTERFACES_PKG__MSG__INFER_RESULTS_ARRAY_H_
