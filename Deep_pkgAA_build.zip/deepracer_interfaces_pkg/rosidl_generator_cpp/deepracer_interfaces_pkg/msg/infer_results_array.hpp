// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef DEEPRACER_INTERFACES_PKG__MSG__INFER_RESULTS_ARRAY_HPP_
#define DEEPRACER_INTERFACES_PKG__MSG__INFER_RESULTS_ARRAY_HPP_

#include "deepracer_interfaces_pkg/msg/detail/infer_results_array__struct.hpp"
#include "deepracer_interfaces_pkg/msg/detail/infer_results_array__builder.hpp"
#include "deepracer_interfaces_pkg/msg/detail/infer_results_array__traits.hpp"

#endif  // DEEPRACER_INTERFACES_PKG__MSG__INFER_RESULTS_ARRAY_HPP_
