# generated from colcon_core/shell/template/command_prefix.sh.em
. "/media/deepracer/wook/FinalCode/Deep_pkgAA/install/deepracer_interfaces_pkg/share/deepracer_interfaces_pkg/package.sh"
. "/media/deepracer/wook/FinalCode/Deep_pkgAA/install/camera_pkg/share/camera_pkg/package.sh"
. "/media/deepracer/wook/FinalCode/Deep_pkgAA/install/deepracer_navigation_pkg/share/deepracer_navigation_pkg/package.sh"
. "/media/deepracer/wook/FinalCode/Deep_pkgAA/install/inference_pkg/share/inference_pkg/package.sh"
. "/media/deepracer/wook/FinalCode/Deep_pkgAA/install/model_optimizer_pkg/share/model_optimizer_pkg/package.sh"
. "/media/deepracer/wook/FinalCode/Deep_pkgAA/install/servo_pkg/share/servo_pkg/package.sh"
