// generated from rosidl_generator_c/resource/idl.h.em
// with input from deepracer_interfaces_pkg:srv/BeginSoftwareUpdateSrv.idl
// generated code does not contain a copyright notice

#ifndef DEEPRACER_INTERFACES_PKG__SRV__BEGIN_SOFTWARE_UPDATE_SRV_H_
#define DEEPRACER_INTERFACES_PKG__SRV__BEGIN_SOFTWARE_UPDATE_SRV_H_

#include "deepracer_interfaces_pkg/srv/detail/begin_software_update_srv__struct.h"
#include "deepracer_interfaces_pkg/srv/detail/begin_software_update_srv__functions.h"
#include "deepracer_interfaces_pkg/srv/detail/begin_software_update_srv__type_support.h"

#endif  // DEEPRACER_INTERFACES_PKG__SRV__BEGIN_SOFTWARE_UPDATE_SRV_H_
