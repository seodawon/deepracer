///////////////////////////////////////////////////////////////////////////////////
//   Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.          //
//                                                                               //
//   Licensed under the Apache License, Version 2.0 (the "License").             //
//   You may not use this file except in compliance with the License.            //
//   You may obtain a copy of the License at                                     //
//                                                                               //
//       http://www.apache.org/licenses/LICENSE-2.0                              //
//                                                                               //
//   Unless required by applicable law or agreed to in writing, software         //
//   distributed under the License is distributed on an "AS IS" BASIS,           //
//   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.    //
//   See the License for the specific language governing permissions and         //
//   limitations under the License.                                              //
///////////////////////////////////////////////////////////////////////////////////

#ifndef INTEL_INFERENCE_ENG_HPP
#define INTEL_INFERENCE_ENG_HPP

#include "inference_pkg/inference_base.hpp"
#include "inference_engine.hpp"
#include "deepracer_interfaces_pkg/msg/evo_sensor_msg.hpp"
#include "deepracer_interfaces_pkg/msg/infer_results_array.hpp"
#include <atomic>

#include <sys/socket.h> // 소켓 관련 헤더
#include <netinet/in.h> // sockaddr_in 구조체 사용을 위한 헤더
#include <arpa/inet.h>  // inet_addr 함수 사용을 위한 헤더
#include <unistd.h>     // close 함수 사용을 위한 헤더
#include <string.h>     // memset 함수 사용을 위한 헤더

//InferReusults 구조체
struct AAInferReusults { //AA에게 보내게될 추론결과 구조체
    std::int32_t class_label;           // 라벨
    float class_prob;         // 프롭
    float x_min;             // 최소 X
    float y_min;            // 최소 Y 
    float x_max;           // 최대 X
    float y_max;          //  최대 Y
};

struct AAImage { //AA에게서 받을 이미지 구조체
    std::uint32_t height;        // 이미지 높이
    std::uint32_t width;         // 이미지 너비
    std::uint8_t is_bigendian;   // 엔디안 여부 (데이터의 바이트 순서)
    std::uint32_t step;          // 한 줄의 데이터 크기 (바이트 단위)
    std::int32_t sec;            // 타임스탬프 초 단위
    std::uint32_t nanosec;       // 타임스탬프 나노초 단위
    std::uint8_t data[57600];    // 이미지 데이터 배열 (크기 57600)
    char encoding[32];           // 이미지 인코딩 형식 (예: "bgr8")
    char frame_id[32];           // 프레임 ID (카메라 또는 센서 식별자)
};

struct AAtoInference{ //AA로부터 인퍼런스 노드가 받게되는 값
    float lidar_data[64];
    AAImage images[2];
};

struct InferencetoAA{ //인퍼런스 노드가 AA에게 보내는 데이터
    AAInferReusults results[9];
    AAImage images[2]; 
};

namespace IntelInferenceEngine {
    class RLInferenceModel : public InferTask::InferenceBase
    {
    /// Concrete inference task class for running reinforcement learning models
    /// on the GPU.
    public:

        /// @param node_name Name of the node to be created.
        /// @param subName Name of the topic to subscribe to for sensor data.
        RLInferenceModel(std::shared_ptr<rclcpp::Node> inferenceNodePtr, const std::string &sensorSubName);
        virtual ~RLInferenceModel();
        virtual bool loadModel(const char* artifactPath,
                               std::shared_ptr<InferTask::ImgProcessBase> imgProcess) override;
        virtual void startInference() override;
        virtual void stopInference() override;
        /// Callback method to retrieve sensor data.
        /// @param msg Message returned by the ROS messaging system.
        void sensorCB(const deepracer_interfaces_pkg::msg::EvoSensorMsg::SharedPtr msg, AAtoInference* rosMsg);
        
        static void* startWebServer(void* arg);

        int sock;
        pthread_t server_thread_;  // 소켓 통신을 위한 스레드
        struct sockaddr_in server_addr;
        AAtoInference* recv_Data = new AAtoInference;

    private:
        /// Inference node object
        std::shared_ptr<rclcpp::Node> inferenceNode;
        /// ROS subscriber object to the desired sensor topic.
        rclcpp::Subscription<deepracer_interfaces_pkg::msg::EvoSensorMsg>::SharedPtr sensorSub_;
        /// ROS publisher object to the desired topic.
        rclcpp::Publisher<deepracer_interfaces_pkg::msg::InferResultsArray>::SharedPtr resultPub_;
        /// Pointer to image processing algorithm.
        std::shared_ptr<InferTask::ImgProcessBase> imgProcess_;
        /// Inference state variable.
        std::atomic<bool> doInference_;
        /// Neural network Inference engine core object.
        InferenceEngine::Core core_;
        /// Inference request object
        InferenceEngine::InferRequest inferRequest_;
        /// Vector of hash map that stores all relevant pre-processing parameters for each input head.
        std::vector<std::unordered_map<std::string, int>> paramsArr_;
        /// Vector of names of the input heads
        std::vector<std::string> inputNamesArr_;
        /// Name of the output layer
        std::string outputName_;
    };
}
#endif