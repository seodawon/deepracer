///////////////////////////////////////////////////////////////////////////////////
// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License").
// You may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
///////////////////////////////////////////////////////////////////////////////////

#include "inference_pkg/intel_inference_eng.hpp"  // 인텔 추론 엔진 관련 헤더 파일 포함
#include "deepracer_interfaces_pkg/srv/inference_state_srv.hpp"  // 추론 상태 서비스 관련 헤더 파일 포함
#include "deepracer_interfaces_pkg/srv/load_model_srv.hpp"  // 모델 로드 서비스 관련 헤더 파일 포함
#include "deepracer_interfaces_pkg/msg/camera_msg.hpp"
#include "deepracer_interfaces_pkg/msg/evo_sensor_msg.hpp"
#include <thread>
#include <atomic>
#include <memory>


namespace InferTask {


/// 추론 작업을 위한 열거형 정의
enum InferTaskType {
    rlTask,           // 강화 학습 작업
    objDetectTask,    // 객체 탐지 작업 (구현 예정)
    numTask           // 작업의 총 개수 (사용하지 않음)
};

/// 전처리 알고리즘을 위한 열거형 정의
enum PreProccessType {
    rgb,                   // RGB 이미지 전처리
    grey,                  // 회색조 이미지 전처리
    greyMask,              // 회색조 + 마스크 전처리
    greyThreshold,         // 회색조 + 임계값 전처리
    greyThresholdMask,     // 회색조 + 임계값 + 마스크 전처리
    greyDiff,              // 회색조 차이 계산 전처리
    numPreProcess          // 전처리 알고리즘의 총 개수 (사용하지 않음)
};

/// InferenceNodeMgr 클래스는 추론 작업을 관리하는 역할을 수행.
/// 노드 이름을 받아와서 추론 작업을 시작/중지하고 센서 데이터를 전달함.
class InferenceNodeMgr : public rclcpp::Node {
public:
    /// 생성자: 노드 이름을 받아와서 초기화. ROS2 노드를 생성하고 서비스들을 설정.
    /// @param nodeName 노드의 이름을 나타내는 문자열 참조.
    InferenceNodeMgr(const std::string & nodeName) : Node(nodeName) {
        RCLCPP_INFO(this->get_logger(), "%s started", nodeName.c_str());  // 노드 시작 로그 출력

        // 모델 로드 서비스 콜백 그룹 생성 (서로 배타적인 콜백 그룹)
        loadModelServiceCbGrp_ = this->create_callback_group(rclcpp::callback_group::CallbackGroupType::MutuallyExclusive);

        // 모델 로드 서비스 생성 및 콜백 함수 등록
        loadModelService_ = this->create_service<deepracer_interfaces_pkg::srv::LoadModelSrv>(
            "load_model", 
            std::bind(&InferTask::InferenceNodeMgr::LoadModelHdl, this, std::placeholders::_1, std::placeholders::_2, std::placeholders::_3), 
            ::rmw_qos_profile_default, 
            loadModelServiceCbGrp_
        );

        // 추론 상태 설정 서비스 콜백 그룹 생성 (서로 배타적인 콜백 그룹)
        setInferenceStateServiceCbGrp_ = this->create_callback_group(rclcpp::callback_group::CallbackGroupType::MutuallyExclusive);

        // 추론 상태 설정 서비스 생성 및 콜백 함수 등록
        setInferenceStateService_ = this->create_service<deepracer_interfaces_pkg::srv::InferenceStateSrv>(
            "inference_state", 
            std::bind(&InferTask::InferenceNodeMgr::InferStateHdl, this, std::placeholders::_1, std::placeholders::_2, std::placeholders::_3), 
            ::rmw_qos_profile_default,
            setInferenceStateServiceCbGrp_
        );

        // 사용 가능한 작업과 전처리 알고리즘을 해시맵에 추가.
        taskList_ = { {rlTask, nullptr} };  // 강화 학습 작업만 초기화 (객체 탐지는 미구현)
        
        preProcessList_ = { 
            {rgb, std::make_shared<RGB>()},  // RGB 전처리 객체 생성 및 등록
            {grey, std::make_shared<Grey>(false, false)},  // 회색조 전처리 객체 생성 및 등록 (마스크/임계값 없음)
            {greyMask, std::make_shared<Grey>(false, true)},  // 회색조 + 마스크 전처리 객체 등록
            {greyThreshold, std::make_shared<Grey>(true, false)},  // 회색조 + 임계값 전처리 객체 등록
            {greyThresholdMask, std::make_shared<Grey>(true, true)},  // 회색조 + 임계값 + 마스크 전처리 객체 등록
            {greyDiff, std::make_shared<GreyDiff>()}  // 회색조 차이 계산 전처리 객체 등록
        };
    }

    /// 소멸자: 기본 소멸자 사용.
    ~InferenceNodeMgr() = default;

    /// 추론 상태 서버를 위한 콜백 함수.
    /// 요청에 따라 추론 작업을 시작하거나 중지하는 역할 수행.
    void InferStateHdl(
        const std::shared_ptr<rmw_request_id_t> request_header,
        std::shared_ptr<deepracer_interfaces_pkg::srv::InferenceStateSrv::Request> req,
        std::shared_ptr<deepracer_interfaces_pkg::srv::InferenceStateSrv::Response> res) 
    {
        (void)request_header;  // 사용하지 않는 매개변수 무시

        auto itInferTask = taskList_.find(req->task_type);  // 요청된 작업 유형 찾기

        res->error = 1;  // 기본적으로 에러 코드 설정

        if (itInferTask != taskList_.end()) {  // 작업 유형이 유효한 경우
            if (!itInferTask->second) {  // 모델이 로드되지 않은 경우 에러 메시지 출력 후 종료
                RCLCPP_INFO(this->get_logger(), "Please load a model before starting inference");
                res->error = 0;
                return;
            }

            if (req->start) {  // 요청이 시작인 경우 추론 시작
                itInferTask->second->startInference();
                RCLCPP_INFO(this->get_logger(), "Inference task (enum %d) has started", req->task_type);
            } else {  // 요청이 중지인 경우 추론 중지
                itInferTask->second->stopInference();
                RCLCPP_INFO(this->get_logger(), "Inference task (enum %d) has stopped", req->task_type);
            }
            
            res->error = 0;  // 성공적으로 처리되었음을 알림
        }
    }

    /// 모델 로드 서버를 위한 콜백 함수.
    /// 요청에 따라 모델과 전처리 알고리즘을 해당 추론 작업에 로드하는 역할 수행.
    void LoadModelHdl(
        const std::shared_ptr<rmw_request_id_t> request_header,
        std::shared_ptr<deepracer_interfaces_pkg::srv::LoadModelSrv::Request> req,
        std::shared_ptr<deepracer_interfaces_pkg::srv::LoadModelSrv::Response> res) 
    {
        (void)request_header;  // 사용하지 않는 매개변수 무시

        auto itInferTask = taskList_.find(req->task_type);  // 요청된 작업 유형 찾기
        auto itPreProcess = preProcessList_.find(req->pre_process_type);  // 요청된 전처리 알고리즘 찾기

        res->error = 1;  // 기본적으로 에러 코드 설정

        if (itInferTask != taskList_.end() && itPreProcess != preProcessList_.end()) {  
            switch(req->task_type) {
                case rlTask:  
                    itInferTask->second.reset(new IntelInferenceEngine::RLInferenceModel(this->shared_from_this(), "/sensor_fusion_pkg/sensor_msg"));
                    break;

                case objDetectTask:  
                    RCLCPP_ERROR(this->get_logger(), "Object detection not implemented");  
                    return;

                default:  
                    RCLCPP_ERROR(this->get_logger(), "Unknown inference task");  
                    return;
            }

            itInferTask->second->loadModel(req->artifact_path.c_str(), itPreProcess->second);  
            res->error = 0;  
        }
    }

private:

    /// 모델 로드 서비스를 위한 ROS 콜백 그룹 정의.
    rclcpp::callback_group::CallbackGroup::SharedPtr loadModelServiceCbGrp_;

    /// 모델 로드 서비스를 위한 ROS 서비스 정의.
    rclcpp::Service<deepracer_interfaces_pkg::srv::LoadModelSrv>::SharedPtr loadModelService_;

    /// 추론 상태 설정 서비스를 위한 ROS 콜백 그룹 정의.
    rclcpp::callback_group::CallbackGroup::SharedPtr setInferenceStateServiceCbGrp_;

    /// 추론 상태 설정 서비스를 위한 ROS 서비스 정의.
    rclcpp::Service<deepracer_interfaces_pkg::srv::InferenceStateSrv>::SharedPtr setInferenceStateService_;

    /// 사용 가능한 추론 작업 목록 (해시맵으로 관리).
    std::unordered_map<int, std::shared_ptr<InferenceBase>> taskList_;

    /// 사용 가능한 전처리 알고리즘 목록 (해시맵으로 관리).
    std::unordered_map<int, std::shared_ptr<ImgProcessBase>> preProcessList_;
};

}  // namespace InferTask

/// 메인 함수: ROS2 노드를 초기화하고 실행.
/// 멀티스레드 실행기를 사용하여 여러 콜백을 동시에 처리함.
int main(int argc, char * argv[]) {
    rclcpp::init(argc, argv);  // ROS2 초기화

    auto node = std::make_shared<InferTask::InferenceNodeMgr>("inference_node");  // InferenceNodeMgr 노드 생성

    rclcpp::executors::MultiThreadedExecutor exec;  // 멀티스레드 실행기 생성

    exec.add_node(node);  // 노드를 실행기에 추가

    exec.spin();  // 실행기 실행 (콜백 처리)

    rclcpp::shutdown();  // ROS2 종료

    return 0;  // 프로그램 종료
}
