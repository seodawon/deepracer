# generated from colcon_core/shell/template/command_prefix.sh.em
. "/media/deepracer/wook/FinalCode/Deep_pkg/install/deepracer_interfaces_pkg/share/deepracer_interfaces_pkg/package.sh"
. "/media/deepracer/wook/FinalCode/Deep_pkg/install/camera_pkg/share/camera_pkg/package.sh"
. "/media/deepracer/wook/FinalCode/Deep_pkg/install/deepracer_navigation_pkg/share/deepracer_navigation_pkg/package.sh"
. "/media/deepracer/wook/FinalCode/Deep_pkg/install/inference_pkg/share/inference_pkg/package.sh"
. "/media/deepracer/wook/FinalCode/Deep_pkg/install/model_optimizer_pkg/share/model_optimizer_pkg/package.sh"
. "/media/deepracer/wook/FinalCode/Deep_pkg/install/servo_pkg/share/servo_pkg/package.sh"
