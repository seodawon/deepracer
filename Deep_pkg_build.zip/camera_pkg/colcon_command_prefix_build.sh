# generated from colcon_core/shell/template/command_prefix.sh.em
. "/media/deepracer/wook/FinalCode/Deep_pkg/install/deepracer_interfaces_pkg/share/deepracer_interfaces_pkg/package.sh"
