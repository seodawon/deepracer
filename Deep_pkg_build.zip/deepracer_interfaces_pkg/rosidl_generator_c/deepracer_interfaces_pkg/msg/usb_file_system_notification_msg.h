// generated from rosidl_generator_c/resource/idl.h.em
// with input from deepracer_interfaces_pkg:msg/USBFileSystemNotificationMsg.idl
// generated code does not contain a copyright notice

#ifndef DEEPRACER_INTERFACES_PKG__MSG__USB_FILE_SYSTEM_NOTIFICATION_MSG_H_
#define DEEPRACER_INTERFACES_PKG__MSG__USB_FILE_SYSTEM_NOTIFICATION_MSG_H_

#include "deepracer_interfaces_pkg/msg/detail/usb_file_system_notification_msg__struct.h"
#include "deepracer_interfaces_pkg/msg/detail/usb_file_system_notification_msg__functions.h"
#include "deepracer_interfaces_pkg/msg/detail/usb_file_system_notification_msg__type_support.h"

#endif  // DEEPRACER_INTERFACES_PKG__MSG__USB_FILE_SYSTEM_NOTIFICATION_MSG_H_
